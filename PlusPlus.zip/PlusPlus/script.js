const btn = document.querySelector(".btn_press");
const theme = document.querySelector("#theme-link");

btn.addEventListener("click", function () {
    if (theme.getAttribute("href") == "light-theme.css") {
        theme.href = "dark-theme.css";
        localStorage.setItem("theme", "dark-theme.css")
        btn.innerHTML = "<i class=\"fa-regular fa-sun fa-2xl\"></i>"
    } else {
        theme.href = "light-theme.css";
        localStorage.setItem("theme", "light-theme.css")
        btn.innerHTML = "<i class=\"fa-regular fa-moon fa-2xl\"></i>"
    }
});

function setTheme() {
    theme.href = localStorage.getItem("theme")
}

setTheme()